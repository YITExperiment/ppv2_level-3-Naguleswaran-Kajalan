print('Hello, World!')
person=input('What is your name?')
print('Hello',person)
