Python 3.9.4 (tags/v3.9.4:1f2e308, Apr  6 2021, 13:40:21) [MSC v.1928 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
= RESTART: C:/Users/micro system/AppData/Local/Programs/Python/Python39/kaja.py
Hello, World!
>>> 
= RESTART: C:/Users/micro system/AppData/Local/Programs/Python/Python39/kaja2.py
Hello, World!
What is your name?kajalan
Hello kajalan
>>> 
= RESTART: C:/Users/micro system/AppData/Local/Programs/Python/Python39/kaja4.py
>>> 
>>> age=12
>>> print(age)
12
>>> 